package Frontend;

public class RunGUI {
        public static void main(String[] args) {
            
        ChessGUI chessBoard = new ChessGUI();
        
        chessBoard.run();

    }
}
